
<?php $__env->startSection('content'); ?>
<section class="dashboard">
    <div class="top">
        <i class="uil uil-bars sidebar-toggle"></i>
        <div class="search-box">
            <i class="uil uil-search"></i>
            <input type="text" placeholder="Search here...">
        </div>
        <img src="/images/profil.png" alt="">
    </div>

    <div class="dash-content">
        <div class="activity">
            <div class="title">
                <i class="uil uil-check-circle"></i>
                <span class="text">Verifikasi Surat</span>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-2">
                    <ul class="m-0 ps-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <table id="datatable" class="table table-hover table-striped align-middle">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No. Surat</th>
                        <th>Pegawai</th>
                        <th>Tujuan</th>
                        <th>Berangkat</th>
                        <th>Kembali</th>
                        <th>Total Biaya</th>
                        <th>Status</th>
                        <th style="width:180px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $badge = ['menunggu'=>'secondary','diterima'=>'success','ditolak'=>'danger'][$s->status] ?? 'secondary';
                            $total = $s->rincianBiaya->jumlah_total ?? 0;
                        ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($s->no_surat); ?></td>
                            <td><?php echo e($s->pegawai->name ?? '-'); ?></td>
                            <td><?php echo e($s->tujuan); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($s->tanggal_berangkat)->format('d/m/Y')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($s->tanggal_kembali)->format('d/m/Y')); ?></td>
                            <td>Rp <?php echo e(number_format($total,0,',','.')); ?></td>
                            <td><span class="badge bg-<?php echo e($badge); ?>"><?php echo e(ucfirst($s->status)); ?></span></td>
                            <td class="d-flex gap-2">
                                <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal"
                                        data-bs-target="#modalDetail<?php echo e($s->id); ?>">
                                    Detail
                                </button>

                                <?php if($s->status === 'menunggu'): ?>
                                    <form action="<?php echo e(route('pimpinan.surat.approve', $s->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-success"
                                                onclick="return confirm('Terima surat ini?')">
                                            Terima
                                        </button>
                                    </form>

                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal"
                                            data-bs-target="#modalTolak<?php echo e($s->id); ?>">
                                        Tolak
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="9" class="text-center">Belum ada pengajuan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>


<?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalDetail<?php echo e($s->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Surat — <?php echo e($s->no_surat); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <dl class="row">
                    <dt class="col-sm-4">Pegawai</dt>
                    <dd class="col-sm-8"><?php echo e($s->pegawai->name ?? '-'); ?></dd>

                    <dt class="col-sm-4">Tujuan</dt>
                    <dd class="col-sm-8"><?php echo e($s->tujuan); ?></dd>

                    <dt class="col-sm-4">Maksud Perjalanan</dt>
                    <dd class="col-sm-8"><?php echo nl2br(e($s->maksud_perjalanan)); ?></dd>

                    <dt class="col-sm-4">Alat Transportasi</dt>
                    <dd class="col-sm-8"><?php echo e($s->alat_transportasi ?? '-'); ?></dd>

                    <dt class="col-sm-4">Tanggal Berangkat</dt>
                    <dd class="col-sm-8"><?php echo e(\Carbon\Carbon::parse($s->tanggal_berangkat)->format('d/m/Y')); ?></dd>

                    <dt class="col-sm-4">Tanggal Kembali</dt>
                    <dd class="col-sm-8"><?php echo e(\Carbon\Carbon::parse($s->tanggal_kembali)->format('d/m/Y')); ?></dd>

                    <dt class="col-sm-4">Rincian Biaya</dt>
                    <dd class="col-sm-8">
                        Uang Harian: Rp <?php echo e(number_format($s->rincianBiaya->uang_harian ?? 0,0,',','.')); ?><br>
                        Transportasi: Rp <?php echo e(number_format($s->rincianBiaya->transportasi ?? 0,0,',','.')); ?><br>
                        Total: <strong>Rp <?php echo e(number_format($s->rincianBiaya->jumlah_total ?? 0,0,',','.')); ?></strong><br>
                        Terbilang: <?php echo e($s->rincianBiaya->terbilang ?? '-'); ?>

                    </dd>

                    <dt class="col-sm-4">Catatan Pimpinan</dt>
                    <dd class="col-sm-8"><?php echo e($s->catatan_pimpinan ?? '-'); ?></dd>
                </dl>
            </div>
            <div class="modal-footer">
                <a href="<?php echo e(route('pegawai.surat.pdf', $s->id)); ?>" class="btn btn-outline-primary" target="_blank">
                    <i class="uil uil-file-download"></i> Lihat/Cetak
                </a>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalTolak<?php echo e($s->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('pimpinan.surat.reject', $s->id)); ?>" method="POST" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title">Tolak Surat — <?php echo e($s->no_surat); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <label>Catatan (opsional)</label>
                <textarea name="catatan_pimpinan" class="form-control" rows="3"
                          placeholder="Alasan penolakan atau catatan"></textarea>
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger">Tolak</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>$(function(){ $('#datatable').DataTable(); });</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\administrasi-imigrasi\resources\views/pimpinan/surat.blade.php ENDPATH**/ ?>