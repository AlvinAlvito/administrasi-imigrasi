<nav>
    <div class="logo-name">
        <div class="logo-image">
            <img src="/images/logo.png" alt="">
        </div>
        <span class="logo_name">
            <?php if(session('role')): ?>
                <?php echo e(ucfirst(session('role'))); ?>

            <?php else: ?>
                Dashboard
            <?php endif; ?>
        </span>
    </div>

    <div class="menu-items">
        <ul class="nav-links">

            
            <?php if(session('is_admin')): ?>
                <li>
                    <a href="<?php echo e(route('admin.index')); ?>" class="<?php echo e(Request::is('admin') ? 'active' : ''); ?>">
                        <i class="uil uil-estate"></i>
                        <span class="link-name">Beranda</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.pegawai.index')); ?>"
                        class="<?php echo e(Request::is('admin/akun-pegawai') ? 'active' : ''); ?>">
                        <i class="uil uil-users-alt"></i>
                        <span class="link-name">Akun Pegawai</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.pimpinan.index')); ?>"
                        class="<?php echo e(Request::is('admin/akun-pimpinan') ? 'active' : ''); ?>">
                        <i class="uil uil-user-check"></i>
                        <span class="link-name">Akun Pimpinan</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.surat.index')); ?>" class="<?php echo e(Request::is('admin/surat') ? 'active' : ''); ?>">
                        <i class="uil uil-clipboard-notes"></i>
                        <span class="link-name">Semua Surat</span>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if(session('is_pimpinan')): ?>
                <li>
                    <a href="<?php echo e(route('pimpinan.index')); ?>" class="<?php echo e(Request::is('pimpinan') ? 'active' : ''); ?>">
                        <i class="uil uil-estate"></i>
                        <span class="link-name">Beranda</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('pimpinan.surat.index')); ?>"
                        class="<?php echo e(Request::is('pimpinan/surat') ? 'active' : ''); ?>">
                        <i class="uil uil-check-circle"></i>
                        <span class="link-name">Verifikasi Surat</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('pimpinan.profil')); ?>"
                        class="<?php echo e(Request::is('pimpinan/profil') ? 'active' : ''); ?>">
                        <i class="uil uil-user"></i>
                        <span class="link-name">Profil</span>
                    </a>
                </li>
            <?php endif; ?>


            
            <?php if(session('is_pegawai')): ?>
                <li>
                    <a href="<?php echo e(route('pegawai.index')); ?>" class="<?php echo e(Request::is('pegawai') ? 'active' : ''); ?>">
                        <i class="uil uil-estate"></i>
                        <span class="link-name">Beranda</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('pegawai.surat.index')); ?>"
                        class="<?php echo e(Request::is('pegawai/surat') ? 'active' : ''); ?>">
                        <i class="uil uil-file-plus-alt"></i>
                        <span class="link-name">Surat Saya</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('pegawai.profil')); ?>"
                        class="<?php echo e(Request::is('pegawai/profil') ? 'active' : ''); ?>">
                        <i class="uil uil-user"></i>
                        <span class="link-name">Profil</span>
                    </a>
                </li>
            <?php endif; ?>


            
            <?php if(!session('is_admin') && !session('is_pimpinan') && !session('is_pegawai')): ?>
                <li>
                    <a href="<?php echo e(route('login')); ?>" class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">
                        <i class="uil uil-estate"></i>
                        <span class="link-name">Beranda</span>
                    </a>
                </li>
            <?php endif; ?>

        </ul>

        <ul class="logout-mode">
            <li>
                <a href="<?php echo e(route('logout')); ?>">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a>
            </li>

            <li class="mode">
                <a href="#">
                    <i class="uil uil-moon"></i>
                    <span class="link-name">Dark Mode</span>
                </a>
                <div class="mode-toggle">
                    <span class="switch"></span>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\administrasi-imigrasi\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>