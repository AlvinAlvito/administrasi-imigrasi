
<?php $__env->startSection('content'); ?>
    <section class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>
            <img src="/images/profil.png" alt="">
        </div>

        <div class="dash-content">
            <div class="activity">
                <div class="title">
                    <i class="uil uil-clipboard-notes"></i>
                    <span class="text">Daftar Semua Surat Perjalanan Dinas</span>
                </div>

                <table id="datatable" class="table table-hover table-striped align-middle">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>No. Surat</th>
                            <th>Pegawai</th>
                            <th>Pimpinan</th>
                            <th>Tujuan</th>
                            <th>Tgl Berangkat</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                            <th>Total Biaya</th>
                            <th>PDF</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($s->no_surat); ?></td>
                                <td><?php echo e($s->pegawai->name ?? '-'); ?></td>
                                <td><?php echo e($s->pimpinan->name ?? '-'); ?></td>
                                <td><?php echo e($s->tujuan); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($s->tanggal_berangkat)->format('d/m/Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($s->tanggal_kembali)->format('d/m/Y')); ?></td>
                                <td>
                                    <?php
                                        $badge =
                                            ['menunggu' => 'secondary', 'diterima' => 'success', 'ditolak' => 'danger'][
                                                $s->status
                                            ] ?? 'secondary';
                                    ?>
                                    <span class="badge bg-<?php echo e($badge); ?>"><?php echo e(ucfirst($s->status)); ?></span>
                                </td>
                                <td>
                                    <?php if($s->rincianBiaya): ?>
                                        Rp <?php echo e(number_format($s->rincianBiaya->jumlah_total, 0, ',', '.')); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    
                                    <a href="<?php echo e(route('admin.surat.pdf', $s->id)); ?>"
                                        class="btn btn-sm btn-outline-primary me-1">
                                        <i class="uil uil-file-download"></i> Cetak
                                    </a>

                                    
                                    <?php if($s->file_surat_pdf): ?>
                                        <a href="<?php echo e(asset($s->file_surat_pdf)); ?>" target="_blank"
                                            class="btn btn-sm btn-soft">
                                            Lihat
                                        </a>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center">Belum ada surat.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
        $(function() {
            $('#datatable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\administrasi-imigrasi\resources\views/admin/surat.blade.php ENDPATH**/ ?>